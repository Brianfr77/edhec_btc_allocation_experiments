# Part 12 Methodology Audit

Part 12 audits the economic ordering of the frozen Part 1 HMM-4 states. It does not re-estimate PCA, HMM, KMeans, portfolio weights, or state posterior probabilities.

The original Part 1 ordering uses an equal-weight stress composite with positive signs for VIX, BAA10Y credit spread, adjusted financial conditions, 10-year real yield, and dollar 4-week change, and negative signs for net liquidity and the 10Y-2Y yield curve. Leave-one-out methods recompute this ordering after dropping one component. The VIX-credit-conditions method uses only market stress and financial conditions. The PC1 method uses saved Part 1 PCA loadings and interprets higher PC1 as higher stress because the VIX, credit-spread, and financial-conditions loadings are jointly positive after orientation.

For each ordering, the same ranked rule is applied: `state_0=3%`, `state_1=1%`, `state_2=0%`, and `state_3=0%`, followed by the original-grid 10% BTC volatility and CVaR contribution cap. This is a sensitivity audit, not rule optimization.
