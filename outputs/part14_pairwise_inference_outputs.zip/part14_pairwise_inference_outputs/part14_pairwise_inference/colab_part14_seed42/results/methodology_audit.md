# Part 14 Methodology Audit

Part 14 applies circular moving-block bootstrap inference to the Part 10 benchmark comparisons.
The sample is the frozen state-aligned target-weight sample from 2018-02-09 to 2026-03-27
with 425 weekly observations.

Bootstrap design:
- Replications: 2000
- Block length: 13 weeks
- Same draw index is used for both scenarios in each pair, preserving common shocks.
- The procedure is conditional on fixed Part 10 scenario weights and fixed Part 1 HMM-4 labels.
- It does not re-estimate PCA/HMM models and does not re-select allocation rules.

Pairs:
- conditional_cap_10pct vs matched_fixed_btc
- conditional_cap_10pct vs cap_only_10pct
- conditional_cap_10pct vs no_btc_baseline
- cap_only_10pct vs matched_fixed_btc

Interpretation boundary:
These confidence intervals support statistical caution around target-weight comparisons. They are not full
model-selection uncertainty intervals and should not be described as nested bootstrap evidence.
