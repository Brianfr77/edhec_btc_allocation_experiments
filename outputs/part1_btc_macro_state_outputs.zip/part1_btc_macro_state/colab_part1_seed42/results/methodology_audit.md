# Part 1 Methodology Audit

## Purpose
This run documents BTC asset role diagnostics and full-sample descriptive macro-state identification. It does not estimate portfolio weights, risk budgets, allocation rules, trading rules, or thesis conclusions.

## Frozen Inputs
- Main asset panel: `data_2026/cleaned/asset_returns_main_weekly.csv`.
- Macro-state panel: `data_2026/cleaned/state_model_panel_weekly.csv`.
- Robustness panel: `data_2026/cleaned/robustness_weekly_panel.csv`.
- Cleaning report: `data_2026/cleaned/cleaning_report.json`.

Input hashes and sample windows are recorded in `run_manifest.json`, `validation_summary.json`, and `data_lineage.csv`.

## BTC Asset Role Diagnostics
The runner computes weekly descriptive statistics, weekly 5% VaR/CVaR, maximum drawdown, pairwise beta, the full return correlation matrix, and 52-week rolling correlations. Sharpe is saved only as a descriptive statistic and is not treated as a primary conclusion metric.

## Macro-State Identification
The state model uses the ten cleaning-report macro predictor mappings. Only the `_z` columns enter PCA. Raw predictor columns are retained for interpreting state profiles. PCA is fixed at five components. The main model is a four-state diagonal Gaussian HMM with multiple initializations and fixed seed `42`. State ordering is deterministic: ascending macro stress composite.

## Robustness and Audit Trail
The runner saves HMM-3, HMM-5, and KMeans-4 auxiliary outputs. The file `hmm_initialization_audit.csv` records every HMM initialization, log-likelihood, convergence flag, iteration count, and whether it was selected as the best run.

## Discussion Boundaries
- State labels are ex-post descriptive labels, not real-time tradable signals.
- Candidate state profiles are not final economic names.
- State-conditioned BTC tables are descriptive diagnostics, not allocation recommendations.
- Portfolio construction, risk contribution, conditional allocation discipline, transaction costs, Autoencoder/LSTM, FRED-MD, CFTC, and ETF flow are outside Part 1.
