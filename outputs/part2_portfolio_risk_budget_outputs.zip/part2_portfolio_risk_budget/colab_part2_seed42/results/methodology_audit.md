# Part 2 Methodology Audit

## Purpose
Part 2 builds no-BTC All Weather and ERC baseline portfolios, then adds fixed BTC weights of 0%, 1%, 2%, 3%, and 5%. It reports return and risk-budget diagnostics only. It does not estimate a conditional allocation rule, trading strategy, transaction costs, or turnover.

## Inputs
- Cleaned asset returns: `data_2026/cleaned/asset_returns_main_weekly.csv`.
- Cleaning report: `data_2026/cleaned/cleaning_report.json`.
- Part 1 HMM-4 state labels: `outputs/part1_btc_macro_state/colab_part1_seed42/results/hmm4_state_labels.csv`.
- Part 1 manifest: `outputs/part1_btc_macro_state/colab_part1_seed42/run_manifest.json`.

The effective Part 2 sample is the inner join between asset returns and HMM-4 labels: 425 weekly observations from 2018-02-09 to 2026-03-27.

## Portfolio Construction
All Weather no-BTC weights are fixed at SPY 30%, TLT 40%, IEF 15%, GLD 7.5%, and DBC 7.5%. ERC uses the same five assets and one static full-sample covariance matrix. Fixed BTC portfolios scale the no-BTC base weights by `1 - btc_weight` and assign the remaining fixed share to BTC.

## Risk Contribution
Volatility contribution uses Euler covariance contribution. CVaR contribution uses empirical portfolio left-tail weeks and reports loss contributions, which can be negative for hedging assets. State-conditioned results group the fixed portfolios by HMM-4 state and do not change weights.

## Discussion Boundaries
- No result in Part 2 is a recommended BTC allocation.
- State-conditioned results are diagnostic and full-sample descriptive.
- BIL, transaction costs, turnover, rolling ERC, and conditional BTC de-risking are outside Part 2.
