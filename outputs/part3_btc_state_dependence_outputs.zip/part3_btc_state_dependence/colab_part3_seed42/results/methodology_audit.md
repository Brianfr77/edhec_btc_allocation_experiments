# Part 3 Methodology Audit

## Purpose
Part 3 tests BTC state dependence and conditional beta diagnostics. It is diagnostic and descriptive. It does not construct portfolio weights, risk-budget thresholds, allocation rules, trading strategies, transaction costs, or thesis conclusions.

## Inputs
- Cleaned asset returns: `data_2026/cleaned/asset_returns_main_weekly.csv`.
- Cleaned state panel with lagged macro predictors: `data_2026/cleaned/state_model_panel_weekly.csv`.
- Part 1 HMM-4 state labels: `outputs/part1_btc_macro_state/colab_part1_seed42/results/hmm4_state_labels.csv`.
- Part 2 risk-budget outputs: `outputs/part2_portfolio_risk_budget/colab_part2_seed42/results/btc_risk_budget_summary.csv`.

The effective Part 3 sample is 425 weekly observations from 2018-02-09 to 2026-03-27.

## State Dependence Diagnostics
The runner recomputes BTC performance by HMM-4 state and recomputes BTC correlations with SPY, TLT, IEF, GLD, DBC, and BIL by state. It verifies these overlapping quantities against the Part 1 light diagnostics before continuing. State-conditioned drawdown is reported in two forms: noncontiguous state-ordered drawdown and worst contiguous same-state episode drawdown.

## Conditional Beta Diagnostics
The dependent variable is `ret_btc`. Each beta is a separate single-predictor OLS diagnostic. The SPY predictor uses same-week `ret_spy`; macro predictors use one-week-lagged full-sample z-score variables from the cleaned state panel. HAC/Newey-West standard errors use a fixed four-week lag.

## Small Sample Handling
States with fewer than 52 weeks are explicitly flagged. Coefficients and confidence intervals are still reported, but state-level inference is treated as unstable.

## Discussion Boundaries
- HMM-4 labels are full-sample ex-post descriptive labels, not real-time signals.
- Macro beta coefficients are z-score sensitivities, not conventional asset-return betas.
- Part 2 outputs are used only as lineage and context, not as inputs to beta estimation.
- Coin Metrics, SHY, IBIT/FBTC, HY OAS, transaction costs, and implementability checks remain outside Part 3.
