# Part 4 Methodology Audit

## Purpose
Part 4 evaluates conditional BTC allocation rules as risk-budgeted satellite diagnostics. It does not estimate a trading strategy, transaction costs, turnover, real-time state signal, or final thesis conclusion.

## Inputs
- Cleaned weekly asset returns from `data_2026/cleaned`.
- Part 1 HMM-4 full-sample ex-post state labels.
- Part 2 fixed BTC risk-budget diagnostics and base portfolio weights.
- Part 3 BTC state-dependence and conditional beta diagnostics.

The effective sample is 425 weekly observations from 2018-02-09 to 2026-03-27.

## Allocation Rules
The main raw rule is `state_0=3%`, `state_1=1%`, `state_2=0%`, and `state_3=0%`. The executed rule applies a 10% BTC risk-budget cap to both full-sample and active-state BTC volatility and CVaR contribution shares. Released BTC allocation is returned pro rata to the non-BTC base portfolio.

## Risk Contributions
Conditional rules use time-varying target weights. Component returns are computed weekly as `weight_i,t * asset_return_i,t`. Volatility contribution is `cov(component_i, portfolio) / portfolio_volatility`; CVaR contribution is the empirical mean component loss in portfolio left-tail weeks.

## Discussion Boundaries
- HMM-4 states are ex-post descriptive groups and not real-time signals.
- The main rule excludes `state_2` because it has only 30 weeks despite strong historical BTC returns.
- BIL cash parking, transaction costs, rebalancing frequency, turnover, and implementability are outside Part 4.
- The sensitivity state_2 low-allocation rule is not the main conclusion rule.
