# Part 6 Methodology Audit

## Purpose
Part 6 evaluates whether the Part 1-5 findings are robust to data-source, cash-proxy, frequency, ETF-era, and credit-proxy substitutions. It is a diagnostic robustness layer, not a new strategy search and not a final thesis conclusion.

## Inputs
- Cleaned weekly returns and robustness panel from `data_2026/cleaned`.
- Part 1 HMM-4 state labels and state-model lineage.
- Part 2 no-BTC All Weather and ERC baseline weights.
- Part 4 executed conditional BTC allocation rules.
- Part 5 one-week-lagged implementability diagnostics.

## Full-Sample Robustness
Coin Metrics BTC and SHY are complete in the 425-week state-aligned sample and are valid full-sample substitutions. HMM states, ERC weights, and conditional rule weights are kept fixed.

## Short-Sample Diagnostics
IBIT/FBTC and HY OAS are not complete in the full sample. IBIT/FBTC begin as return series on 2024-01-19. HY OAS overlap begins in 2023. These outputs are marked as observational or overlap-only diagnostics and are not used as substitutes for the full-sample evidence.

## Monthly Frequency
Monthly robustness compounds weekly returns within each calendar month and assigns the month-end HMM state from the last available Friday. No monthly PCA/HMM model is estimated.

## Boundaries
- No HMM re-estimation.
- No ERC re-optimization.
- No new BTC weight selection.
- No final thesis conclusion.
