# Part 8 Methodology Audit

Part 8 quantifies uncertainty around the Part 3, Part 4/5, and Part 7 evidence chain. It does not search for a new BTC allocation rule and does not mutate upstream outputs.

The main uncertainty method is circular moving block bootstrap with `2000` replications and block length `13` weeks. The same draw index is used within each sample domain so cross-asset and cross-strategy shocks remain aligned.

The HMM ensemble is a sensitivity audit for Part 7 state drift. It changes seeds, initial windows, and refit frequency, then reports state agreement and rule-signal sensitivity. It does not replace the canonical Part 7 result.
