# Part 9 Methodology Audit

Part 9 is a supplementary audit of regime stability. It does not re-estimate PCA/HMM models, does not search for new BTC allocation rules, and does not modify Parts 1-8.

The audit compares Part 7 pseudo real-time MAP states with Part 1 full-sample HMM labels, documents disagreement episodes, measures how state disagreement changes BTC allocation signals, and summarizes Part 8 HMM ensemble sensitivity.

The outputs are intended for thesis caveats and supplementary tables, not as a new strategy result.
